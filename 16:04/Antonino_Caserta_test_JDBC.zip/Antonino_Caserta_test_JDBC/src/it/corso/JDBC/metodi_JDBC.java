package it.corso.JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.cj.jdbc.MysqlDataSource;

public class metodi_JDBC {

	private Connection con = null;

	public Connection startConnection(String databaseName) throws SQLException {
		if (con == null) {
			MysqlDataSource dataSource = new MysqlDataSource();
			dataSource.setServerName("127.0.0.1");
			dataSource.setPortNumber(3306);
			dataSource.setUser("root");
			dataSource.setPassword("Macbook75");
			dataSource.setDatabaseName(databaseName); 

			con = dataSource.getConnection();
		}
		return con;
	}

	public void useDatabase(String dbName) throws SQLException {
		try {
			startConnection(dbName);
			String sql = "USE " + dbName;
			try (PreparedStatement stmt = con.prepareStatement(sql)) {
				stmt.executeUpdate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createDatabase(String dbName) throws SQLException {
		try {
			startConnection(null);
			String sql = "CREATE DATABASE IF NOT EXISTS " + dbName;
			try (PreparedStatement stmt = con.prepareStatement(sql)) {
				stmt.executeUpdate();
				System.out.println("Il database '" + dbName + "' è stato creato con successo");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void createTableU(String nomeTabella, String dbName) throws SQLException {
		try {
			startConnection(dbName);
			String sql = "CREATE TABLE IF NOT EXISTS " + nomeTabella + " (" +
					"id INT PRIMARY KEY NOT NULL, " +
					"Cognome VARCHAR(255), " +
					"Nome VARCHAR(255))";
			try (PreparedStatement stmt = con.prepareStatement(sql)) {
				stmt.executeUpdate();
				System.out.println("Tabella 'U' (Utente) creata con successo.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createTableL(String nomeTabella, String dbName) throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS " + nomeTabella + " (" +
				"id INT NOT NULL, " +
				"Titolo TEXT, " +
				"Autore TEXT, " +
				"PRIMARY KEY (id))";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.executeUpdate();
			System.out.println("Tabella 'L' (Libro) creata con successo.");
		}
	}

	public void createTableP(String nomeTabella, String dbName) throws SQLException {
		String sql = "CREATE TABLE IF NOT EXISTS " + nomeTabella + " (" +
				"id INT NOT NULL, " +
				"inizio DATE, " +
				"fine DATE, " +
				"id_L INT, " +
				"id_U INT, " +
				"PRIMARY KEY (id), " +
				"FOREIGN KEY (id_L) REFERENCES L(id), " +
				"FOREIGN KEY (id_U) REFERENCES U(id))"; 
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.executeUpdate();
			System.out.println("Tabella 'P' (Prestito) creata con successo.");
		}
	}
	public void insertIntoTableU() throws SQLException {
		String[] nomi = {"Mario", "Andrea", "Massimo", "Sara", "Marco", "Marzia"};
		String[] cognomi = {"Rossi", "Verdi", "Bianchi", "Vallieri", "Graviglia", "Esposito"};

		String sql = "INSERT INTO U (id, Nome, Cognome) VALUES (?, ?, ?)";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			for (int i = 0; i < nomi.length; i++) {
				stmt.setInt(1, i + 1); 
				stmt.setString(2, nomi[i]);
				stmt.setString(3, cognomi[i]);
				stmt.executeUpdate();
			}
			System.out.println("Dati inseriti nella tabella 'U' (Utente) con successo.");
		}
	}

	//Query 1
	public void queryLibriPrestati(String utente) throws SQLException {
		String sql = "SELECT L.Titolo, P.inizio " +
				"FROM P " +
				"INNER JOIN L ON P.id_L = L.id " +
				"INNER JOIN U ON P.id_U = U.id " +
				"WHERE U.Cognome = ? " +
				"ORDER BY P.inizio";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setString(1, utente);
			try (ResultSet rs = stmt.executeQuery()) {
				System.out.println("Libri prestati all'utente " + utente + " in ordine cronologico:");
				while (rs.next()) {
					String titolo = rs.getString("Titolo");
					String dataInizio = rs.getString("inizio");
					System.out.println(titolo + " - Data inizio prestito: " + dataInizio);
				}
			}
		}
	}
	//Query 2
	public void queryTopLettori() throws SQLException {
		String sql = "SELECT U.Nome, U.Cognome, COUNT(P.id_U) AS LibriLetti " +
				"FROM U " +
				"LEFT JOIN P ON U.id = P.id_U " +
				"GROUP BY U.id " +
				"ORDER BY LibriLetti DESC " +
				"LIMIT 3";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			try (ResultSet rs = stmt.executeQuery()) {
				System.out.println("I primi tre lettori che hanno letto più libri:");
				while (rs.next()) {
					String nome = rs.getString("Nome");
					String cognome = rs.getString("Cognome");
					int libriLetti = rs.getInt("LibriLetti");
					System.out.println(nome + " " + cognome + " - Libri letti: " + libriLetti);
				}
			}
		}
	}
	//Query 3
	public void queryLibriNonRestituiti() throws SQLException {
		String sql = "SELECT U.Nome, U.Cognome, L.Titolo " +
				"FROM U " +
				"JOIN L ON U.id = P.id_U " +
				"WHERE NOT EXISTS (" +
				"    SELECT * " +
				"    FROM P " +
				"    WHERE P.id_L = L.id AND P.fine IS NULL" +
				")";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			try (ResultSet rs = stmt.executeQuery()) {
				System.out.println("Possessori dei libri non ancora restituiti:");
				while (rs.next()) {
					String nome = rs.getString("Nome");
					String cognome = rs.getString("Cognome");
					String titoloLibro = rs.getString("Titolo");
					System.out.println(nome + " " + cognome + " - Titolo libro: " + titoloLibro);
				}
			}
		}
	}
	//Query 4
	public void queryStoricoPrestiti(int idUtente, String dataInizio, String dataFine) throws SQLException {
		String sql = "SELECT L.Titolo, P.inizio, P.fine " +
				"FROM P " +
				"JOIN L ON P.id_L = L.id " +
				"WHERE P.id_U = ? AND P.inizio >= ? AND P.fine <= ?";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			stmt.setInt(1, idUtente);
			stmt.setString(2, dataInizio);
			stmt.setString(3, dataFine);
			try (ResultSet rs = stmt.executeQuery()) {
				System.out.println("Storico dei libri chiesti in prestito dall'utente " + idUtente + " nel periodo " + dataInizio + " - " + dataFine + ":");
				while (rs.next()) {
					String titoloLibro = rs.getString("Titolo");
					String dataInizioPrestito = rs.getString("inizio");
					String dataFinePrestito = rs.getString("fine");
					System.out.println("Titolo libro: " + titoloLibro + ", Inizio prestito: " + dataInizioPrestito + ", Fine prestito: " + dataFinePrestito);
				}
			}
		}
	}  
	//Query 6
	public void queryDurataPrestito() throws SQLException {
		String sql = "SELECT P.id, U.Nome AS NomeUtente, U.Cognome AS CognomeUtente, L.Titolo AS TitoloLibro, P.inizio, P.fine " +
				"FROM P " +
				"JOIN U ON P.id_U = U.id " +
				"JOIN L ON P.id_L = L.id " +
				"WHERE DATEDIFF(P.fine, P.inizio) > 15";
		try (PreparedStatement stmt = con.prepareStatement(sql)) {
			try (ResultSet rs = stmt.executeQuery()) {
				System.out.println("Prestiti la cui durata supera i 15 giorni:");
				while (rs.next()) {
					int idPrestito = rs.getInt("id");
					String nomeUtente = rs.getString("NomeUtente");
					String cognomeUtente = rs.getString("CognomeUtente");
					String titoloLibro = rs.getString("TitoloLibro");
					String dataInizio = rs.getString("inizio");
					String dataFine = rs.getString("fine");
					System.out.println("ID prestito: " + idPrestito + ", Utente: " + nomeUtente + " " + cognomeUtente + ", Titolo libro: " + titoloLibro + ", Data inizio: " + dataInizio + ", Data fine: " + dataFine);
				}
			}
		}
	}
}
