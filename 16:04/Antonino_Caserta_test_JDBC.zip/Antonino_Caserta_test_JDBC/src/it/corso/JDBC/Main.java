package it.corso.JDBC;

import java.sql.SQLException;

//Antonino Caserta

public class Main {

	public static void main(String[] args) throws SQLException {

		metodi_JDBC db = new metodi_JDBC();
		
		String dbName = "test_JDBC";
		
	    try {
	        
	        db.createDatabase(dbName);
	        
	        db.useDatabase(dbName);
	        
	        db.createTableU("U", dbName);
	        
	        db.createTableL("L", dbName);
	        
	        db.createTableP("P", dbName);
	        
	        db.insertIntoTableU();
	        
	        db.queryLibriPrestati("Vallieri");
	        
	        db.queryTopLettori();
	        
	        db.queryStoricoPrestiti(4, "2024-01-01", "2024-07-01");
	        
	        db.queryDurataPrestito();
	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
}
