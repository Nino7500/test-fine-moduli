package it.corso.testFinale;


public class Volo {
	
    private String sigla;
    private Aereoporto partenza;
    private Aereoporto destinazione;
    private String aereo;

    private Passeggero[] passeggeri;
    private int numPasseggeri;

    public Volo(String sigla, Aereoporto partenza, Aereoporto destinazione, String aereo, int maxPasseggeri) {
        this.sigla = sigla;
        this.partenza = partenza;
        this.destinazione = destinazione;
        this.aereo = aereo;
        this.passeggeri = new Passeggero[maxPasseggeri];
        this.numPasseggeri = 0;
    }

    public void aggiungiPasseggero(Passeggero passeggero) {
        if (numPasseggeri < passeggeri.length) {
            passeggeri[numPasseggeri] = passeggero;
            numPasseggeri++;
        } else {
            System.out.println("Il volo è pieno, impossibile aggiungere altri passeggeri.");
        }
    }

    public String descriviVolo() {
        return "Volo " + sigla + " " + partenza.getCitta() + " " + partenza.getNome() +
                " - " + destinazione.getCitta() + " " + destinazione.getNome();
    }

    public String[] elencoNomiPasseggeri() {
        String[] nomi = new String[numPasseggeri];
        for (int i = 0; i < numPasseggeri; i++) {
            nomi[i] = passeggeri[i].getNome();
        }
        return nomi;
    }

    public String[] elencoPostiVegetariani() {
        int count = 0;
        for (Passeggero passeggero : passeggeri) {
            if (passeggero != null && passeggero.getPastoRichiesto().equals("vegetariano")) {
                count++;
            }
        }
        String[] postiVegetariani = new String[count];
        int index = 0;
        for (Passeggero passeggero : passeggeri) {
            if (passeggero != null && passeggero.getPastoRichiesto().equals("vegetariano")) {
                postiVegetariani[index] = passeggero.getPostoAssegnato();
                index++;
            }
        }
        return postiVegetariani;
    }
}
   