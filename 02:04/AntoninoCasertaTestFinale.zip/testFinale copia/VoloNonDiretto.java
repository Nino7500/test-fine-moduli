package it.corso.testFinale;

public class VoloNonDiretto extends Volo {
    private Aereoporto[] scali;
    private int numScali;

    public VoloNonDiretto(String sigla, Aereoporto partenza, Aereoporto destinazione, String aereo, int maxPasseggeri, int maxScali) {
        super(sigla, partenza, destinazione, aereo, maxPasseggeri);
        this.scali = new Aereoporto[maxScali];
        this.numScali = 0;
    }

    public void aggiungiScalo(Aereoporto scalo) {
        if (numScali < scali.length) {
            scali[numScali] = scalo;
            numScali++;
        } else {
            System.out.println("Numero massimo di scali raggiunto.");
        }
    }

    public String descriviVoloNonDiretto() {
        StringBuilder descrizione = new StringBuilder(super.descriviVolo());
        descrizione.append(" via ");
        for (int i = 0; i < numScali; i++) {
            descrizione.append(scali[i].getCitta()).append(" ").append(scali[i].getNome());
            if (i < numScali - 1) {
                descrizione.append(" - ");
            }
        }
        return descrizione.toString();
    }
}
