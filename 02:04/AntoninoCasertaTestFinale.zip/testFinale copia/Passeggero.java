package it.corso.testFinale;

public class Passeggero {
	
    private String nome;
    private String nazionalita;
    private String siglaVolo;
    private String postoAssegnato;
    private String pastoRichiesto;

    public Passeggero(String nome, String nazionalita, String siglaVolo, String postoAssegnato, String pastoRichiesto) {
        this.nome = nome;
        this.nazionalita = nazionalita;
        this.siglaVolo = siglaVolo;
        this.postoAssegnato = postoAssegnato;
        this.pastoRichiesto = pastoRichiesto;
    }

    public String getNome() {
        return nome;
    }

    public String getNazionalita() {
        return nazionalita;
    }

    public String getSiglaVolo() {
        return siglaVolo;
    }

    public String getPostoAssegnato() {
        return postoAssegnato;
    }

    public String getPastoRichiesto() {
        return pastoRichiesto;
    }

    public void cambiaPosto(String nuovoPosto) {
        this.postoAssegnato = nuovoPosto;
    }
}
     