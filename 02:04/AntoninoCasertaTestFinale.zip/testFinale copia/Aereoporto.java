package it.corso.testFinale;

public class Aereoporto {
	
    private String nome;
    private String citta;
    private String sigla;

    public Aereoporto(String nome, String citta, String sigla) {
        this.nome = nome;
        this.citta = citta;
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public String getCitta() {
        return citta;
    }

    public String getSigla() {
        return sigla;
    }
}
