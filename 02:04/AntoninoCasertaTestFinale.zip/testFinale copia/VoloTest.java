package it.corso.testFinale;

public class VoloTest {
	
    public static void main(String[] args) {
    	
        Aereoporto roma = new Aereoporto("Fiumicino", "Roma", "FCO");
        Aereoporto londra = new Aereoporto("Heathrow", "Londra", "LHR");
        Aereoporto palermo = new Aereoporto("Falcone e Borsellino", "Palermo", "PMO");
        Aereoporto milano = new Aereoporto("Malpensa", "Milano", "MXP");

        Passeggero passeggero1 = new Passeggero("Pippo Rossi", "Italiana", "AZ108", "16F", "vegetariano");
        Passeggero passeggero2 = new Passeggero("Pluto Verdi", "Italiana", "AZ108", "17A", "standard");
        Passeggero passeggero3 = new Passeggero("Luca Bianchi", "Italiana", "AZ108", "18B", "vegetariano");
        Passeggero passeggero4 = new Passeggero("topo Neri", "Italiana", "AZ108", "19C", "standard");

        Volo voloDiretto = new Volo("AZ108", roma, londra, "Airbus300", 150);
        voloDiretto.aggiungiPasseggero(passeggero1);
        voloDiretto.aggiungiPasseggero(passeggero2);
        voloDiretto.aggiungiPasseggero(passeggero3); 
        voloDiretto.aggiungiPasseggero(passeggero4); 

        System.out.println("Descrizione volo diretto: " + voloDiretto.descriviVolo());
        System.out.print("Elenco passeggeri: ");
        String[] nomiPasseggeri = voloDiretto.elencoNomiPasseggeri();
        for (int i = 0; i < nomiPasseggeri.length; i++) {
            System.out.print(nomiPasseggeri[i]);
            if (i < nomiPasseggeri.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();
        
        System.out.print("Posti vegetariani: ");
        String[] postiVegetariani = voloDiretto.elencoPostiVegetariani();
        for (int i = 0; i < postiVegetariani.length; i++) {
            System.out.print(postiVegetariani[i]);
            if (i < postiVegetariani.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println();

        VoloNonDiretto voloNonDiretto1 = new VoloNonDiretto("BA202", londra, milano, "Boeing777", 200, 2);
        voloNonDiretto1.aggiungiScalo(palermo);
        voloNonDiretto1.aggiungiScalo(roma);

        VoloNonDiretto voloNonDiretto2 = new VoloNonDiretto("AF303", milano, roma, "Airbus A320", 180, 1);
        voloNonDiretto2.aggiungiScalo(londra);
       

        System.out.println("Descrizione volo non diretto: " + voloNonDiretto1.descriviVoloNonDiretto());
        System.out.println("Descrizione volo non diretto: " + voloNonDiretto2.descriviVoloNonDiretto());
    }
}